# Sistemi Genit TODO

## Setup
- [x] Generate app logo (icon.png + splash + favicon + android-icon-foreground)
- [x] Update app.config.ts branding (appName "Sistemi Genit", logoUrl)
- [x] Configure theme tokens (Albanian Vyapar palette)

## Data layer
- [x] AsyncStorage data context with full schema (company, products, customers, suppliers, invoices, purchases, payments, priceHistory, stockAdjustments, stores)
- [x] Seed default demo data on first launch
- [x] Helper functions: money(L), today(), nowTime(), partyDue, supplierDue, stockOf, activePrice, etc.

## Navigation
- [x] Bottom tab bar: Kryefaqe / Raporte / Artikuj / Menu / Cilësime
- [x] Stack screens for sale, party select, item select, etc.
- [x] Albanian icon mapping in icon-symbol.tsx

## Screens
- [x] Home (invoice list, quick links, FAB)
- [x] Sale (invoice editor with cash/credit toggle)
- [x] Party Select / Party Quick Form
- [x] Sale Item Select / Add Item to Sale
- [x] Invoice Preview (58mm/80mm/A4) — via expo-print PDF
- [x] Invoice Detail
- [x] Items list / Item Detail / Product Form (with units & price history)
- [x] Parties list / Party Form / Party Detail / Party Payment
- [x] Suppliers list / Supplier Detail (shared form & payment)
- [x] Purchase editor / Purchase Detail
- [x] Reports (8 reports with date range)
- [x] Stock Adjustment
- [x] All Transactions
- [x] Company Profile
- [x] Backup / Import (JSON via FileSystem + DocumentPicker)
- [x] Menu / Txn Settings

## Features
- [x] Sales invoice creation with multi-line items + profit calc
- [x] Cash/credit mode + payment recording
- [x] Customer ledger (invoices, payments, balance)
- [x] Supplier ledger
- [x] Purchase invoice creation (stock additive, supplier billing)
- [x] Product CRUD with multi-unit (Copë, Koli, Paletë) + price history
- [x] Stock tracking (decrement on sale, increment on purchase, manual adjustments)
- [x] Live search on party/product/report pickers
- [x] Receipt rendering (58mm/80mm/A4) + share as PDF
- [x] Backup as JSON file via expo-sharing
- [x] Restore from JSON file via document picker

## Polish
- [x] Verify TypeScript clean
- [x] Unit tests for store helpers (7 passing)
- [x] All onPress handlers wired
- [x] Save final checkpoint

## Full HTML coverage — Reports (38 types)

The original HTML defines 38 report types in `V32_REPORT_TYPES`. Need to implement them all in the unified Reports screen with the same filter set (report picker, client, supplier, product, store, unit, date range) and PDF + share export.

Sales
- [ ] salesSummary — Regjistri Përmbledhës i Shitjeve
- [ ] salesAnalytic — Regjistri Analitik i Shitjeve
- [ ] salesSummaryInvoice — Faturë përmbledhëse shitje
- [ ] salesByProduct — Shitje sipas artikullit
- [ ] salesByClient — Shitje sipas klientit
- [ ] salesByUnit — Shitje sipas njësisë
- [ ] salesDaily — Shitje ditore
- [ ] salesInvoiceBatch — Fatura shitje të renditura

Purchases
- [ ] purchaseAnalytic — Regjistri Analitik i Blerjeve
- [ ] purchaseBySupplier — Blerje sipas furnitorit
- [ ] purchaseByProduct — Blerje sipas artikullit
- [ ] purchaseDaily — Blerje ditore
- [ ] purchaseInvoiceBatch — Fatura blerje të renditura

Inventory / stock
- [ ] itemCard — Kartela e Artikullit
- [ ] stockByWarehouse — Gjendja sipas magazinave
- [ ] stockMovement — Lëvizjet e magazinës
- [ ] stockSummary — Gjendja aktuale e stokut
- [ ] supplyNeed — Kërkesë furnizimi
- [ ] warehouseStockAsOf — Gjendje magazine datë
- [ ] itemAnalysis — Analizë artikulli

Manager / profit
- [ ] managerProfitItem — Fitimi për artikull
- [ ] managerProfitInvoice — Fitimi për faturë
- [ ] managerTopProducts — Top artikujt
- [ ] managerTopClients — Top klientët
- [ ] managerMarginByClient — Marzhi sipas klientit
- [ ] managerDailyProfit — Fitimi ditor
- [ ] managerSalesVsPurchases — Krahasim shitje vs blerje
- [ ] managerInventoryValue — Vlera e inventarit
- [ ] managerSlowMovingStock — Artikuj pa lëvizje
- [ ] managerWarehouseTurnover — Qarkullimi sipas magazinës

Parties / receivables
- [ ] supplierBalances — Detyrime sipas furnitorëve
- [ ] clientBalances — Detyrime sipas klientëve
- [ ] supplierLedger — Kartela furnitorit
- [ ] clientLedger — Kartela klientit
- [ ] unpaidInvoices — Fatura pa paguara
- [ ] clientSalesHistoryAnalytic — Historik shitjesh klienti analitik
- [ ] clientBillingPayments — Faturime pagesa klientit
- [ ] supplierBillingPayments — Faturime pagesa furnitorit

## Modules / pages from HTML — gap audit
- [ ] Unified Reports tab with searchable picker for all 38 reports + filters
- [ ] PDF export per report (A4 landscape) via expo-print
- [ ] Share-sheet export of report PDF via expo-sharing
- [ ] Item detail page with sales/purchase history and price history
- [ ] Supplier ledger payment recording reused (already partially)
- [ ] Visible profit / margin panel on sale screen (already wired but verify)
- [ ] Visible stock impact on purchase screen (verify)
- [ ] Fitim/Marzh badges on home invoice list


## Crash on launch (APK) — investigation
- [ ] Check `app/_layout.tsx` for synchronous failures during startup
- [ ] Verify all icon-symbol mappings used by tabs/screens exist (missing icon → crash on Android)
- [ ] Check `lib/store.ts` initial-load path for invalid JSON / undefined access
- [ ] Verify `expo-print` / `expo-sharing` / `expo-document-picker` configured for Android
- [ ] Verify `app.config.ts` has valid Android package name and adaptive icon assets
- [ ] Add ErrorBoundary at root so any future render error is shown instead of a silent close
- [ ] Add tests + checkpoint and ask user to re-publish


## Phase A6 — Pricing, filters, suggestions, Excel export
- [x] Schema: 10 named price lists per item; default list name table on company; per-customer defaultPriceList
- [x] Items module: edit list names + 10 prices per item
- [x] Party form: pick default price list for each customer
- [x] Sale flow: auto-pick list from customer; override per line via picker
- [x] Sale invoice: round-off as +/− buttons
- [x] Reports engine: purchaseSuggestion report (every item sold in period)
- [x] Reports engine: multi-select items filter; unit filter
- [x] Reports engine: stock report per-unit columns (njësi 1/2/3 quantities)
- [x] Reports UI: live refresh on filter change; multi-item chips; unit chips
- [x] Reports UI: Excel (xlsx) export keeping the table layout
- [x] Tests + checkpoint (23 passing)

## Phase B (paused) — Bluetooth ESC/POS printing
- [x] react-native-bluetooth-classic installed
- [ ] Pair-list screen, ESC/POS formatter, print from invoice


## Phase B1 — Bug fixes & per-store stock (nga video + raportime)
- [ ] BUG: free qty (sasi dhuratë) duhet të konvertohet me koeficientin e njësisë (10 koli + 2 dhuratë → zbres 2×koef, jo 2 copë)
- [ ] BUG: koeficienti i njësisë në formën e artikullit rri gjithmonë 1 / nuk editohet — bëj input të pastër
- [ ] BUG: raportet e inventarit nuk e zbresin sasinë reale / nuk tregojnë gjendje sipas magazinës në dy njësi
- [ ] Stoku të ruhet për (artikull × magazinë), jo numër i vetëm total
- [ ] Shto fushën "Magazina/Vendndodhja" te forma e artikullit (opening stock per store)
- [ ] Shitja/blerja zbret/shton stokun e magazinës së zgjedhur në faturë
- [ ] Transferi i stokut lëviz gjendje mes magazinave (real)
- [ ] Raport inventari: filter Magazinë + filter Njësi, gjendje në 2 njësi (bazë + sekondare)
- [ ] Filtra të zgjeruar në raporte: lloji i transaksionit, statusi (paguar/pjesërisht/papaguar), partia, kategoria, magazina, njësia
- [ ] Teste për konvertimin e free qty dhe gjendjen per-store

## Phase B2 — Invoice payment UX + fast report filters + daily totals report
- [x] Sale invoice: "Paguar të plotë" button auto-fills paid = total
- [x] Sale invoice: "Dhënë" (amount given) field with automatic Kusuri (change) display, no negative balance
- [x] Purchase invoice: same paid-full button
- [x] Reports: fast live text-search filter field (artikull, njësi, parti) combinable
- [x] Reports: filter matching normalized (case + whitespace) so selections refresh table live
- [x] New report "Fatura Totale Sot": Nr, Artikull, Njësia, Sasi shitur, Sasi dhuratë, Çmim, Vlerë, Çmim/copë
- [x] Tests + checkpoint (26 passing)

## Phase B3 — Export fixes + clickable save buttons + online multi-user
- [x] BUG: PDF export prints whole report ignoring the in-results text search; must export only filtered/visible rows
- [x] BUG: Excel export prints whole report ignoring the in-results text search; must export only filtered/visible rows
- [x] BUG: Sale/Purchase "Ruaj" & "Ruaj & i ri" buttons sit under the system navbar and are hard to tap — add safe-area bottom padding so they are fully tappable
- [ ] Online multi-user sync (server + DB): push/pull data so multiple users share live data, optimized (delta sync, debounce)
- [ ] Tests + checkpoint
