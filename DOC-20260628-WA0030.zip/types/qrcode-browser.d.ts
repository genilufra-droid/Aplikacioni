/**
 * Minimal typings for the browser build of the `qrcode` package. The package's
 * own types only cover the package root, not the `qrcode/lib/browser` subpath
 * we import to keep Metro/Hermes happy.
 */
declare module "qrcode/lib/browser" {
  interface QRCodeToStringOptions {
    type?: "svg" | "utf8" | "terminal";
    margin?: number;
    width?: number;
    errorCorrectionLevel?: "L" | "M" | "Q" | "H";
    color?: { dark?: string; light?: string };
  }

  const QRCode: {
    toString(text: string, options?: QRCodeToStringOptions): Promise<string>;
    toCanvas(...args: unknown[]): Promise<unknown>;
    toDataURL(...args: unknown[]): Promise<string>;
  };

  export default QRCode;
}
