import React from "react";
import { FlatList, Pressable, Text, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { Header, Btn } from "@/components/ui-kit";
import { router, useLocalSearchParams } from "expo-router";
import { fmt, money, num, supplierDue, useStore } from "@/lib/store";

export default function SupplierDetailScreen() {
  const colors = useColors();
  const { db } = useStore();
  const { name } = useLocalSearchParams<{ name: string }>();
  const supplier = db.suppliers.find((c) => c.name === name);
  const due = supplierDue(db, name as string);

  type Row = {
    kind: "purchase" | "payment";
    date: string;
    ref: string;
    debit: number;
    credit: number;
    balance: number;
    payload: any;
  };

  const rows: Row[] = React.useMemo(() => {
    const purs = db.purchases
      .filter((p) => p.supplier === name)
      .map((p) => ({
        kind: "purchase" as const,
        date: p.date,
        ref: `#${p.no}`,
        debit: num(p.total),
        credit: num(p.paid),
        payload: p,
      }));
    const pays = db.payments
      .filter((p) => p.partyType === "supplier" && p.party === name)
      .map((p) => ({
        kind: "payment" as const,
        date: p.date,
        ref: p.ref || p.method,
        debit: 0,
        credit: num(p.amount),
        payload: p,
      }));
    const all = [...purs, ...pays].sort((a, b) => a.date.localeCompare(b.date));
    let bal = num(supplier?.openingBalance || 0);
    return all.map((r) => {
      bal += r.debit - r.credit;
      return { ...r, balance: bal } as Row;
    });
  }, [db.purchases, db.payments, name, supplier]);

  if (!supplier) {
    return (
      <ScreenContainer>
        <Header title="Furnitor" back={() => router.back()} />
        <Text style={{ textAlign: "center", marginTop: 40, color: colors.muted }}>Nuk u gjet.</Text>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer>
      <Header title={supplier.name} back={() => router.back()} />
      <View
        style={{
          margin: 12,
          backgroundColor: colors.surface,
          padding: 14,
          borderRadius: 10,
          borderWidth: 1,
          borderColor: colors.border,
        }}
      >
        <Text style={{ fontSize: 18, fontWeight: "900", color: colors.foreground }}>{supplier.name}</Text>
        {supplier.phone ? <Text style={{ color: colors.muted, marginTop: 4 }}>{supplier.phone}</Text> : null}
        <View style={{ flexDirection: "row", gap: 10, marginTop: 10 }}>
          <View style={{ flex: 1, backgroundColor: "#f0f9ff", padding: 10, borderRadius: 8 }}>
            <Text style={{ fontSize: 12, color: colors.muted }}>Detyrim per pagese</Text>
            <Text style={{ fontSize: 18, fontWeight: "900", color: due > 0 ? colors.error : colors.success }}>
              {money(due, db.company.currency)}
            </Text>
          </View>
        </View>
        <View style={{ flexDirection: "row", gap: 8, marginTop: 12 }}>
          <Btn
            title="Pagese"
            icon="creditcard.fill"
            onPress={() => router.push({ pathname: "/party-payment", params: { name: supplier.name, kind: "supplier" } } as any)}
            style={{ flex: 1 }}
          />
          <Btn
            title="Modifiko"
            variant="soft"
            icon="pencil"
            onPress={() => router.push({ pathname: "/party-form", params: { id: String(supplier.id), kind: "supplier" } } as any)}
            style={{ flex: 1 }}
          />
        </View>
        <View style={{ flexDirection: "row", gap: 8, marginTop: 8 }}>
          <Btn
            title="Kartela"
            icon="doc.fill"
            variant="ghost"
            onPress={() =>
              router.push({
                pathname: "/(tabs)/reports",
                params: { type: "supplierLedger", supplier: supplier.name },
              } as any)
            }
            style={{ flex: 1 }}
          />
          <Btn
            title="Blerje"
            icon="chart.bar.fill"
            variant="ghost"
            onPress={() =>
              router.push({
                pathname: "/(tabs)/reports",
                params: { type: "purchaseBySupplier", supplier: supplier.name },
              } as any)
            }
            style={{ flex: 1 }}
          />
        </View>
      </View>

      <FlatList
        data={rows.slice().reverse()}
        keyExtractor={(_, idx) => String(idx)}
        contentContainerStyle={{ paddingBottom: 40 }}
        ListEmptyComponent={
          <Text style={{ textAlign: "center", color: colors.muted, marginTop: 30 }}>Asnje transaksion ende.</Text>
        }
        renderItem={({ item }) => (
          <Pressable
            onPress={() => {
              if (item.kind === "purchase") {
                router.push({ pathname: "/purchase/[no]", params: { no: String(item.payload.no) } } as any);
              }
            }}
            style={{
              backgroundColor: colors.surface,
              marginHorizontal: 12,
              marginVertical: 4,
              padding: 12,
              borderRadius: 8,
              borderWidth: 1,
              borderColor: colors.border,
            }}
          >
            <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
              <Text style={{ fontWeight: "800", color: colors.foreground }}>
                {item.kind === "purchase" ? "Blerje" : "Pagese"} {item.ref}
              </Text>
              <Text style={{ color: colors.muted }}>{item.date}</Text>
            </View>
            <View style={{ flexDirection: "row", justifyContent: "space-between", marginTop: 6 }}>
              <Text style={{ color: colors.muted, fontSize: 12 }}>
                Dt: {fmt(item.debit)} • Kr: {fmt(item.credit)}
              </Text>
              <Text style={{ fontWeight: "800", color: item.balance > 0 ? colors.error : colors.success }}>
                Bal: {fmt(item.balance)}
              </Text>
            </View>
          </Pressable>
        )}
      />
    </ScreenContainer>
  );
}
