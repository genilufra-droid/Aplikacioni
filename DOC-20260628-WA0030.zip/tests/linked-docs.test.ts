import { describe, it, expect } from "vitest";
import {
  migrateDB,
  commitSaleInvoice,
  commitPurchaseInvoice,
  reverseOutboundDoc,
  reverseInboundDoc,
  stockInStore,
  type DB,
  type MultiDB,
  type Product,
  type Invoice,
  type Purchase,
} from "../lib/store";
import { serializeMultiBackup, parseMultiBackup } from "../lib/backup";

const WH = "Magazina kryesore";

function makeProduct(): Product {
  return {
    id: 1,
    name: "UJE 0.5L",
    salePiece: 25,
    buyPiece: 18,
    stock: 300,
    stockByStore: { [WH]: 300 },
    units: [
      { name: "Copë", coef: 1 },
      { name: "Koli", coef: 12 },
    ],
  };
}

function makeDB(): DB {
  const db: DB = {
    company: { name: "TEST", currency: "LEK" },
    stores: [WH],
    products: [makeProduct()],
    customers: [{ id: 1, name: "Klient" }],
    suppliers: [{ id: 1, name: "Furnitor" }],
    invoices: [],
    purchases: [],
    payments: [],
    priceHistory: [],
    stockAdjustments: [],
    expenses: [],
    expenseCategories: [],
    storeTransfers: [],
    settings: { favoriteReports: [] },
    nextInvoice: 1,
    nextPurchase: 1,
  };
  return migrateDB(db);
}

/** Build a sale invoice with a single line of `qty` Koli (+ `freeQty` Koli free). */
function makeInvoice(db: DB, qtyKoli: number, freeKoli = 0): Invoice {
  const rate = 300; // per koli
  return {
    no: db.nextInvoice,
    date: "2026-06-25",
    time: "10:00",
    customer: "Klient",
    billingName: "Klient",
    store: WH,
    mode: "Me arke",
    items: [
      {
        productName: "UJE 0.5L",
        qty: qtyKoli,
        freeQty: freeKoli,
        unit: "Koli",
        rate,
        buyRate: 216,
        total: rate * qtyKoli,
        cost: 216 * qtyKoli,
      },
    ],
    subtotal: rate * qtyKoli,
    roundOff: 0,
    total: rate * qtyKoli,
    paid: rate * qtyKoli,
    due: 0,
    paymentType: "Cash",
    totalCost: 216 * qtyKoli,
    profit: (rate - 216) * qtyKoli,
  };
}

function makePurchase(db: DB, qtyKoli: number, freeKoli = 0): Purchase {
  const rate = 216;
  return {
    no: db.nextPurchase,
    date: "2026-06-25",
    time: "10:00",
    supplier: "Furnitor",
    store: WH,
    mode: "Me arke",
    items: [
      {
        productName: "UJE 0.5L",
        qty: qtyKoli,
        freeQty: freeKoli,
        unit: "Koli",
        rate,
        buyRate: rate,
        total: rate * qtyKoli,
        cost: rate * qtyKoli,
      },
    ],
    subtotal: rate * qtyKoli,
    roundOff: 0,
    total: rate * qtyKoli,
    paid: rate * qtyKoli,
    due: 0,
    paymentType: "Cash",
  };
}

describe("Test 1 — sale auto Fletë Dalje deducts stock exactly once", () => {
  it("10 koli (×12 = 120 copë) deducted once and linked", () => {
    const db = makeDB();
    const res = commitSaleInvoice(db, makeInvoice(db, 10), { autoOutbound: true });
    expect(res.error).toBeUndefined();
    const p = res.db.products.find((x) => x.name === "UJE 0.5L")!;
    expect(stockInStore(p, WH)).toBe(180); // 300 - 120, ONCE
    expect((res.db.outboundDocs || []).length).toBe(1);
    expect(res.invoice.linkedOutboundDocNo).toBeTruthy();
    expect(res.invoice.linkedOutboundDocId).toBe((res.db.outboundDocs || [])[0].id);
    expect(res.invoice.autoCreateOutboundDoc).toBe(true);
    // The linked doc carries the base quantity in pieces.
    expect((res.db.outboundDocs || [])[0].lines[0].baseQty).toBe(120);
    expect((res.db.outboundDocs || [])[0].sourceType).toBe("SALE_INVOICE");
    // No duplicate outbound movement: exactly one "outbound" movement row.
    const outMoves = (res.db.stockMovements || []).filter((m) => m.docType === "outbound");
    expect(outMoves.length).toBe(1);
  });
});

describe("Test 2 — gift/free quantity still deducts stock (total 132 copë once)", () => {
  it("10 koli + 1 koli free → total 132 copë deducted, split into 2 lines", () => {
    const db = makeDB();
    const res = commitSaleInvoice(db, makeInvoice(db, 10, 1), { autoOutbound: true });
    expect(res.error).toBeUndefined();
    const p = res.db.products.find((x) => x.name === "UJE 0.5L")!;
    expect(stockInStore(p, WH)).toBe(168); // 300 - (11×12) deducted ONCE
    const lines = (res.db.outboundDocs || [])[0].lines;
    // The free qty is now its own gift line, so there are 2 lines.
    expect(lines.length).toBe(2);
    // Total physical movement across all lines = 132 copë.
    const totalBase = lines.reduce((s, l) => s + l.baseQty, 0);
    expect(totalBase).toBe(132);
  });
});

describe("Test 2b — gift split: sold value 3000, gift line value 0, stock 132", () => {
  it("10 koli @ 300 + 1 koli DHURATË → sold value 3000, gift 0, total stock 132", () => {
    const db = makeDB();
    const res = commitSaleInvoice(db, makeInvoice(db, 10, 1), { autoOutbound: true });
    expect(res.error).toBeUndefined();
    const lines = (res.db.outboundDocs || [])[0].lines;

    // Line 0 — SOLD line.
    const sold = lines[0];
    expect(sold.unit).toBe("Koli");
    expect(sold.qty).toBe(10);
    expect(sold.coef).toBe(12);
    expect(sold.baseQty).toBe(120); // 10 × 12 copë
    expect(sold.price).toBe(300); // per Koli
    expect(sold.value).toBe(3000); // 10 × 300 — gift does NOT add value
    expect(sold.isGift).toBeFalsy();
    expect(sold.costPiece).toBe(216);

    // Line 1 — GIFT line (DHURATË): price 0, value 0, still moves stock.
    const gift = lines[1];
    expect(gift.isGift).toBe(true);
    expect(gift.qty).toBe(1);
    expect(gift.baseQty).toBe(12); // 1 × 12 copë (still deducts stock)
    expect(gift.price).toBe(0);
    expect(gift.value).toBe(0);

    // Financial total of the doc = sold only = 3000 (NOT 3300, NOT 107×300).
    const docTotal = lines.reduce((s, l) => s + (l.value || 0), 0);
    expect(docTotal).toBe(3000);
    // Physical total across all lines = 132 copë.
    const totalBase = lines.reduce((s, l) => s + l.baseQty, 0);
    expect(totalBase).toBe(132);
  });
});

describe("Test 3 — auto toggle OFF keeps the legacy behaviour", () => {
  it("deducts stock once, creates NO Fletë Dalje", () => {
    const db = makeDB();
    const res = commitSaleInvoice(db, makeInvoice(db, 10), { autoOutbound: false });
    expect(res.error).toBeUndefined();
    const p = res.db.products.find((x) => x.name === "UJE 0.5L")!;
    expect(stockInStore(p, WH)).toBe(180); // still deducted, but legacy path
    expect((res.db.outboundDocs || []).length).toBe(0);
    expect(res.invoice.autoCreateOutboundDoc).toBe(false);
    expect(res.invoice.linkedOutboundDocId).toBeUndefined();
    // Legacy ledger: a "sale" movement is recorded.
    const saleMoves = (res.db.stockMovements || []).filter((m) => m.docType === "sale");
    expect(saleMoves.length).toBe(1);
  });
});

describe("Test 4 — purchase auto Fletë Hyrje adds stock exactly once", () => {
  it("10 koli (120 copë) added once and linked", () => {
    const db = makeDB();
    const res = commitPurchaseInvoice(db, makePurchase(db, 10), { autoInbound: true });
    expect(res.error).toBeUndefined();
    const p = res.db.products.find((x) => x.name === "UJE 0.5L")!;
    expect(stockInStore(p, WH)).toBe(420); // 300 + 120, ONCE
    expect((res.db.inboundDocs || []).length).toBe(1);
    expect(res.purchase.linkedInboundDocNo).toBeTruthy();
    expect(res.purchase.autoCreateInboundDoc).toBe(true);
    const inMoves = (res.db.stockMovements || []).filter((m) => m.docType === "inbound");
    expect(inMoves.length).toBe(1);
  });
});

describe("Edit reversal — no double counting", () => {
  it("editing a sale reverses the old Fletë Dalje and re-applies the new one", () => {
    const db = makeDB();
    const first = commitSaleInvoice(db, makeInvoice(db, 10), { autoOutbound: true });
    expect(stockInStore(first.db.products.find((x) => x.name === "UJE 0.5L")!, WH)).toBe(180);

    // Edit invoice #1 down to 5 koli (60 copë).
    const editedInvoice = { ...makeInvoice(first.db, 5), no: first.invoice.no };
    const second = commitSaleInvoice(first.db, editedInvoice, {
      autoOutbound: true,
      editingNo: first.invoice.no,
    });
    expect(second.error).toBeUndefined();
    const p = second.db.products.find((x) => x.name === "UJE 0.5L")!;
    expect(stockInStore(p, WH)).toBe(240); // 300 - 60, NOT 120
    expect((second.db.outboundDocs || []).length).toBe(1); // old doc removed, one remains
    expect((second.db.invoices || []).length).toBe(1);
  });

  it("reverseOutboundDoc restores stock and drops the doc + movements", () => {
    const db = makeDB();
    const res = commitSaleInvoice(db, makeInvoice(db, 10), { autoOutbound: true });
    const reversed = reverseOutboundDoc(res.db, res.invoice.linkedOutboundDocId!);
    expect(stockInStore(reversed.products.find((x) => x.name === "UJE 0.5L")!, WH)).toBe(300);
    expect((reversed.outboundDocs || []).length).toBe(0);
    expect((reversed.stockMovements || []).filter((m) => m.docType === "outbound").length).toBe(0);
  });

  it("reverseInboundDoc subtracts stock and drops the doc + movements", () => {
    const db = makeDB();
    const res = commitPurchaseInvoice(db, makePurchase(db, 10), { autoInbound: true });
    const reversed = reverseInboundDoc(res.db, res.purchase.linkedInboundDocId!);
    expect(stockInStore(reversed.products.find((x) => x.name === "UJE 0.5L")!, WH)).toBe(300);
    expect((reversed.inboundDocs || []).length).toBe(0);
  });
});

describe("Insufficient stock blocks the auto Fletë Dalje", () => {
  it("returns an error and mutates nothing", () => {
    const db = makeDB();
    // 30 koli = 360 copë > 300 available.
    const res = commitSaleInvoice(db, makeInvoice(db, 30), { autoOutbound: true });
    expect(res.error).toBeTruthy();
    expect(stockInStore(res.db.products.find((x) => x.name === "UJE 0.5L")!, WH)).toBe(300);
    expect((res.db.outboundDocs || []).length).toBe(0);
    expect((res.db.invoices || []).length).toBe(0);
  });
});

describe("Backup/restore keeps the links intact (PART 11)", () => {
  it("round-trips linkedOutboundDocId / linkedInboundDocId", () => {
    let db = makeDB();
    const sale = commitSaleInvoice(db, makeInvoice(db, 5), { autoOutbound: true });
    db = sale.db;
    const purchase = commitPurchaseInvoice(db, makePurchase(db, 5), { autoInbound: true });
    db = purchase.db;

    const mdb: MultiDB = {
      schema: 2,
      activeCompanyId: "co-1",
      companies: [
        {
          id: "co-1",
          name: "TEST",
          currency: "LEK",
          status: "active",
          createdAt: "2026-06-25T00:00:00Z",
        },
      ],
      data: { "co-1": db },
    };
    const raw = serializeMultiBackup(mdb);
    const parsed = parseMultiBackup(raw);
    expect(parsed.ok).toBe(true);
    const restored = parsed.mdb!.data["co-1"];

    const inv = restored.invoices.find((i) => i.no === sale.invoice.no)!;
    const pur = restored.purchases.find((p) => p.no === purchase.purchase.no)!;
    expect(inv.linkedOutboundDocId).toBe(sale.invoice.linkedOutboundDocId);
    expect(inv.linkedOutboundDocNo).toBe(sale.invoice.linkedOutboundDocNo);
    expect(pur.linkedInboundDocId).toBe(purchase.purchase.linkedInboundDocId);
    expect((restored.outboundDocs || []).length).toBe(1);
    expect((restored.inboundDocs || []).length).toBe(1);
  });
});
