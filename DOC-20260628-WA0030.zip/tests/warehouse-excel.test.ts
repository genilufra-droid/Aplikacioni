import { describe, it, expect } from "vitest";
import * as XLSXStyle from "xlsx-js-style";
import { buildWarehouseDocWorkbook, WAREHOUSE_XLSX_COLUMNS } from "../lib/warehouse-excel";
import { warehouseDocToPrintable } from "../lib/print-templates";
import type { Company, OutboundDoc, InboundDoc } from "../lib/store";

const company: Company = {
  name: "RUGOVE LUSHNJE",
  address: "Rruga Kongresi i Lushnjes",
  city: "Lushnjë",
  currency: "ALL",
};

const outbound: OutboundDoc = {
  id: 1,
  no: "FD-2026-0017680",
  date: "2026-06-25",
  warehouse: "Magazina kryesore",
  status: "saved",
  createdAt: "2026-06-25T10:00:00Z",
  sourceType: "SALE_INVOICE",
  sourceInvoiceNo: 17680,
  customerName: "Marketi Te Ura",
  destinationAddress: "Rruga e Durrësit, Tiranë",
  lines: [
    { productName: "Ujë Rugove 0.5L", unit: "Koli", qty: 11, coef: 12, baseQty: 132, price: 300, costPiece: 18, value: 3300 },
  ],
};

describe("buildWarehouseDocWorkbook — real styled .xlsx", () => {
  it("produces a valid xlsx workbook (PK zip) with the warehouse layout", () => {
    const doc = warehouseDocToPrintable(outbound, "outbound", company);
    const wb = buildWarehouseDocWorkbook(doc, company);
    const buf: Buffer = XLSXStyle.write(wb, { type: "buffer", bookType: "xlsx" }) as Buffer;
    // .xlsx files are ZIP archives → must start with the "PK" magic bytes.
    expect(buf.slice(0, 2).toString()).toBe("PK");
  });

  it("WAREHOUSE_XLSX_COLUMNS matches the 8 warehouse columns", () => {
    expect(Array.from(WAREHOUSE_XLSX_COLUMNS)).toEqual([
      "Nr",
      "Emërtimi i mallit",
      "Njësia",
      "Sasia",
      "Koef",
      "Sasia Copë",
      "Çmimi",
      "Vlefta",
    ]);
  });

  it("carries merged title, header block, total and signatures (≥ 20 merges)", () => {
    const doc = warehouseDocToPrintable(outbound, "outbound", company);
    const wb = buildWarehouseDocWorkbook(doc, company);
    const ws = wb.Sheets[wb.SheetNames[0]];
    // title(1) + company(1) + addr(1) + 8 header fields × 2 + total(1) + 4 signatures = 24
    expect((ws["!merges"] || []).length).toBeGreaterThanOrEqual(20);
    expect(ws["!cols"]).toHaveLength(8);
    expect(ws["!rows"].length).toBeGreaterThan(10);
  });

  it("writes the selected-unit price and value (Koli @ 300 → 3300), not piece price", () => {
    const doc = warehouseDocToPrintable(outbound, "outbound", company);
    const wb = buildWarehouseDocWorkbook(doc, company);
    const ws = wb.Sheets[wb.SheetNames[0]];
    const buf: Buffer = XLSXStyle.write(wb, { type: "buffer", bookType: "xlsx" }) as Buffer;
    const rb = XLSXStyle.read(buf, { type: "buffer" });
    const aoa = XLSXStyle.utils.sheet_to_json(rb.Sheets[rb.SheetNames[0]], { header: 1 }) as any[];
    const row = aoa.find((r) => r[1] === "Ujë Rugove 0.5L");
    // [Nr, Emërtimi, Njësia, Sasia, Koef, Sasia Copë, Çmimi, Vlefta]
    expect(row[2]).toBe("Koli");
    expect(row[3]).toBe(11);
    expect(row[4]).toBe(12);
    expect(row[5]).toBe(132);
    expect(row[6]).toBe(300); // Çmimi per selected unit
    expect(row[7]).toBe(3300); // Vlefta = 11 × 300
    // Cells must carry styles (borders) — proves it is a styled, not plain, sheet.
    expect(ws["A1"].s).toBeTruthy();
  });

  it("inbound (Fletë Hyrje) uses the same layout with a Furnitori field", () => {
    const inbound: InboundDoc = {
      id: 2,
      no: "FH-2026-0004521",
      date: "2026-06-25",
      warehouse: "Magazina kryesore",
      status: "saved",
      createdAt: "2026-06-25T11:00:00Z",
      sourceType: "PURCHASE_INVOICE",
      sourcePurchaseNo: 4521,
      supplierName: "Distributori Rugove SHPK",
      supplierInvoiceNo: "F-4521",
      lines: [
        { productName: "Ujë Rugove 0.5L", unit: "Koli", qty: 50, coef: 12, baseQty: 600, price: 216, costPiece: 18, value: 10800 },
      ],
    };
    const doc = warehouseDocToPrintable(inbound, "inbound", company);
    expect(doc.title).toBe("FLETË HYRJE");
    const wb = buildWarehouseDocWorkbook(doc, company);
    const ws = wb.Sheets[wb.SheetNames[0]];
    const cells = Object.keys(ws)
      .filter((k) => !k.startsWith("!"))
      .map((k) => ws[k].v);
    expect(cells).toContain("Furnitori");
    expect(cells).toContain("Magazinieri");
  });
});
