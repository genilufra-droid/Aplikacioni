import { describe, it, expect } from "vitest";
import { migrateDB, unifiedDocuments, filterUnifiedDocs, type DB } from "../lib/store";

// v1.0.14 — Home "Filtro Sipas" modal: unified document list + combined
// (document-type + payment-status) filtering.

function makeDB(): DB {
  const db: DB = {
    company: { name: "TEST", currency: "LEK" },
    stores: ["Magazina kryesore"],
    products: [],
    customers: [{ id: 1, name: "Klient A" }],
    suppliers: [{ id: 1, name: "Furnitor B" }],
    invoices: [
      // sale, fully paid
      { no: 1, date: "2026-06-10", time: "09:00", customer: "Klient A", mode: "Me arke", items: [], subtotal: 3000, roundOff: 0, total: 3000, paid: 3000, due: 0, paymentType: "Cash", totalCost: 0, profit: 0 } as any,
      // sale, partially paid
      { no: 2, date: "2026-06-12", time: "10:00", customer: "Klient A", mode: "Me detyrim", items: [], subtotal: 10000, roundOff: 0, total: 10000, paid: 4000, due: 6000, paymentType: "Cash", totalCost: 0, profit: 0 } as any,
    ],
    purchases: [
      // purchase, unpaid
      { no: 1, date: "2026-06-11", time: "11:00", supplier: "Furnitor B", mode: "Me detyrim", items: [], subtotal: 5000, roundOff: 0, total: 5000, paid: 0, due: 5000, paymentType: "Cash" } as any,
    ],
    payments: [],
    priceHistory: [],
    stockAdjustments: [],
    expenses: [],
    expenseCategories: [],
    storeTransfers: [],
    transfers: [
      { id: 1, transferNo: "TR-20260613-001", date: "2026-06-13", fromWarehouse: "Magazina kryesore", toWarehouse: "Furgoni", product: "X", unit: "Copë", qty: 10, pieces: 10, createdAt: "2026-06-13T00:00:00.000Z" },
    ],
    settings: { favoriteReports: [] },
    nextInvoice: 3,
    nextPurchase: 2,
  };
  return migrateDB(db);
}

describe("unifiedDocuments", () => {
  it("merges sales, purchases and transfers into one list", () => {
    const docs = unifiedDocuments(makeDB());
    expect(docs.length).toBe(4);
    expect(docs.filter((d) => d.kind === "sale").length).toBe(2);
    expect(docs.filter((d) => d.kind === "purchase").length).toBe(1);
    expect(docs.filter((d) => d.kind === "transfer").length).toBe(1);
  });

  it("sorts newest first by date", () => {
    const docs = unifiedDocuments(makeDB());
    expect(docs[0].date).toBe("2026-06-13"); // transfer
    expect(docs[docs.length - 1].date).toBe("2026-06-10"); // earliest sale
  });

  it("normalizes party labels per kind", () => {
    const docs = unifiedDocuments(makeDB());
    const sale = docs.find((d) => d.kind === "sale")!;
    const purchase = docs.find((d) => d.kind === "purchase")!;
    const transfer = docs.find((d) => d.kind === "transfer")!;
    expect(sale.party).toBe("Klient A");
    expect(purchase.party).toBe("Furnitor B");
    expect(transfer.party).toBe("Magazina kryesore → Furgoni");
    expect(transfer.total).toBe(0);
  });
});

describe("filterUnifiedDocs", () => {
  const docs = () => unifiedDocuments(makeDB());

  it("returns everything when no type/status is selected", () => {
    expect(filterUnifiedDocs(docs(), [], []).length).toBe(4);
    expect(filterUnifiedDocs(docs(), undefined, undefined).length).toBe(4);
    expect(filterUnifiedDocs(docs(), ["all"], ["all"]).length).toBe(4);
  });

  it("filters by a single document type", () => {
    expect(filterUnifiedDocs(docs(), ["sale"], []).every((d) => d.kind === "sale")).toBe(true);
    expect(filterUnifiedDocs(docs(), ["purchase"], []).length).toBe(1);
    expect(filterUnifiedDocs(docs(), ["transfer"], []).length).toBe(1);
  });

  it("filters by multiple document types (union)", () => {
    const res = filterUnifiedDocs(docs(), ["sale", "purchase"], []);
    expect(res.length).toBe(3);
    expect(res.every((d) => d.kind !== "transfer")).toBe(true);
  });

  it("filters by payment status across types", () => {
    // paid -> only the fully paid sale
    expect(filterUnifiedDocs(docs(), [], ["paid"]).map((d) => d.kind)).toEqual(["sale"]);
    // unpaid -> only the unpaid purchase
    const unpaid = filterUnifiedDocs(docs(), [], ["unpaid"]);
    expect(unpaid.length).toBe(1);
    expect(unpaid[0].kind).toBe("purchase");
    // due -> the partial sale + the unpaid purchase
    expect(filterUnifiedDocs(docs(), [], ["due"]).length).toBe(2);
  });

  it("excludes transfers when a specific payment status is selected", () => {
    const res = filterUnifiedDocs(docs(), ["transfer"], ["paid"]);
    expect(res.length).toBe(0);
  });

  it("combines type AND status (sale + paid)", () => {
    const res = filterUnifiedDocs(docs(), ["sale"], ["paid"]);
    expect(res.length).toBe(1);
    expect(res[0].kind).toBe("sale");
    expect(res[0].total).toBe(3000);
  });

  it("combines type AND status returning empty when none match (purchase + paid)", () => {
    expect(filterUnifiedDocs(docs(), ["purchase"], ["paid"]).length).toBe(0);
  });
});
