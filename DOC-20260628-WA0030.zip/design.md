# Sistemi Genit - Mobile App Design

## Concept
Albanian business management app (Vyapar clone) for small businesses to manage sales invoices, purchases, customers (klientë), suppliers (furnitorë), inventory (artikuj/magazina), and reports. All copy is in Albanian.

## Brand
- **Name**: Sistemi Genit
- **Colors**: Primary blue `#0b83d8`, success green `#18b884`, danger red `#ef1744`, soft background `#eaf4fb`, surface `#ffffff`
- **Tone**: Clean, professional, similar to Vyapar/Tally — info-dense but mobile-friendly.

## Screens (28 total)

### Tab navigation (5 tabs at bottom)
1. **Kryefaqe (Home)** — invoice list, quick links, FAB to create sale
2. **Raporte (Reports)** — type picker + filters + result list
3. **Artikuj (Items)** — product catalog with search + stock
4. **Menu** — links to suppliers, purchases, company, backup
5. **Cilësime (Settings)** — company, backup, txn settings

### Stack screens (pushed)
- Sale (Shitje) — invoice editor with cash/credit toggle
- Party Select (Zgjidh klientin)
- Party Quick Form (Shto klient)
- Add Item to Sale (Shto artikuj në shitje)
- Sale Item Select
- Invoice Preview (58mm/80mm/A4)
- Invoice Detail
- Items list / Item Detail / Product Form / Price History
- Parties list / Party Form / Party Detail / Party Payment
- Suppliers list / Supplier Form / Supplier Detail / Supplier Payment
- Purchase (Blerje) editor
- Purchase Item Select / Add Purchase Item / Purchase Detail
- Stock Adjustment (Rregullim stoku)
- All Transactions
- Company Profile
- Backup / Import
- Txn Settings

## Primary Content per Screen

### Home
- Header: company logo + name + bell/settings icons
- Tabs: Dokumentet | Klientët
- Quick Links grid (4 icons): Shto Dok, Shto Blerje, Raport Shitje, Cilësime, Të gjitha
- Search bar
- Recent invoice cards (party, no, date, total, paid badge)
- FAB: "💰 Faturë e re shitje"

### Sale Invoice Editor
- Header back + title "Shitje" + Me detyrim/Me arkë toggle
- Meta row: Nr.Fature, Data, Ora
- Magazina selector
- Klienti picker (opens party select)
- "Artikujt e faturuar" list with item cards (qty, unit, price, line total, delete)
- Subtotal/quantity summary
- "+ Shto artikuj" button
- Pagesa/Rrumbullakimi: round-off, total, paid, balance, change, payment method
- Profit panel: sale value, cost, profit, margin
- Sticky bottom: Ruaj & i ri | Ruaj | More options

### Items
- Header with company logo block
- Quick links (Online Store stub, Stock Summary, Item Settings, Show All)
- Magazina filter, search bar
- Product cards: name, category badge, sale/purchase prices, stock
- FAB: "+ Shto artikull"

### Reports
- Filters: report type (live search), client, supplier, product, date range, unit, magazina
- Buttons: Print Preview / Excel (CSV) / PDF (share) / Pastro filtrat
- Output: dynamic tables for each report type

## Key User Flows
1. **New sale**: Home → FAB → Sale → pick klient (Party Select) → "+ Shto artikuj" → search/select product → set qty/unit/price → Ruaj item → repeat → set paid → Ruaj invoice → preview/share
2. **New customer**: Parties tab → "+ Shto" → fill form → Ruaj
3. **Record payment**: Party Detail → "Shto pagesë" → fill amount → Ruaj
4. **New purchase**: Menu → Blerje → similar to sale but supplier-side
5. **Stock adjustment**: Menu → Menaxhim magazine → choose add/reduce → product/qty → Ruaj
6. **Reports**: Reports tab → choose report type → set filters → preview → share

## Color System
- Primary: `#0b83d8` (blue)
- Success: `#18b884` / paid badges `#d9f8ee` text `#0a9b6d`
- Warning: `#fff1c7` text `#b77900` (open invoices)
- Danger: `#ef1744` (FAB, delete)
- Surface: `#ffffff`, page bg `#eaf4fb`
- Text: `#252a34` primary, `#6b7280` muted
- Borders: `#e4e9ef`

## Data Model (AsyncStorage)
Single JSON object `sistemi_genit_db_v1` with:
- `company` (name, address, phone, nipt, email, currency, logoUri, footer)
- `stores` (string[])
- `products` (id, code, barcode, name, category, store, salePiece, buyPiece, stock, minStock, units[{name, coef}])
- `customers` (id, name, phone, nipt, city, address, openingBalance, limit, note)
- `suppliers` (same shape as customers)
- `invoices` (no, date, time, customer, billingName, store, mode, items[], roundOff, total, paid, due, paymentType, note, deleted?)
- `purchases` (similar with supplier)
- `payments` (party type, party, date, amount, method, ref, note)
- `priceHistory` (product, fromDate, salePiece, buyPiece, note)
- `stockAdjustments` (date, store, product, unit, qty, type, price, details)
- `nextInvoice`, `nextPurchase`

## Design Notes
- Use FlatList for all lists.
- Use modal-based pickers for party/product (push screens).
- Bottom tab bar present on Home/Reports/Items/Menu/Settings; hidden on stack screens.
- Avoid web printing; for "print" provide share-as-text/PDF via expo-print + expo-sharing.
- Receipts (58mm / 80mm / A4) rendered as plain ScrollView with monospace font, then exported as PDF.
