/** @type {const} */
const themeColors = {
  primary: { light: '#0b83d8', dark: '#3aa6f3' },
  background: { light: '#eaf4fb', dark: '#0e141b' },
  surface: { light: '#ffffff', dark: '#1b232c' },
  foreground: { light: '#252a34', dark: '#ECEDEE' },
  muted: { light: '#6b7280', dark: '#9BA1A6' },
  border: { light: '#e4e9ef', dark: '#2a3440' },
  success: { light: '#18b884', dark: '#22c993' },
  warning: { light: '#f59e0b', dark: '#fbbf24' },
  error: { light: '#ef1744', dark: '#f87171' },
};

module.exports = { themeColors };
